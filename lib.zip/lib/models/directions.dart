class Directions
{
  String? readableAddress;
  String? locationName;
  String? locationID;
  double? locationLat;
  double? locationLng;

  Directions({
    this.readableAddress,
    this.locationName,
    this.locationID,
    this.locationLat,
    this.locationLng
});
}